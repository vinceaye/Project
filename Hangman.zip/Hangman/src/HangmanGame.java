import java.util.Scanner;

public class HangmanGame
{
    public static void main(String[] args)
    {
        Scanner scnr = new Scanner(System.in);


        while(true)
        {
            System.out.println("Enter the hidden word");
            String hiddenWord = scnr.next();
            HangmanClient newGame = new HangmanClient(hiddenWord);
            newGame.beginGame();
            System.out.println("Would you like to try again? (y/n)");
            String decision = scnr.next().toLowerCase();
            if (decision.equals("y"))
            {
                System.out.println("New game has begun.");
            }
            else
            {
                System.out.println("Thanks for playing!");
                break;
            }
        }
    }
}
