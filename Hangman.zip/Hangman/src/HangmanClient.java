import java.util.Scanner;
import java.util.ArrayList;

public class HangmanClient
{
    private String hiddenWord;
    private int hiddenWordLength;
    //counts up to 6, which is the final amount of guesses
    private int turnNum = 1;

    Scanner scnr = new Scanner(System.in);
    //Saves correct letters and incorrect letters
    ArrayList<Character> correctGuesses = new ArrayList<Character>();
    ArrayList<Character> incorrectGuesses = new ArrayList<Character>();

    public HangmanClient(String hiddenWord)
    {
        //constructor, which sets up the game to have the hidden word entered by a user
        this.hiddenWord = hiddenWord;
        hiddenWordLength = hiddenWord.length();

    }
    public int getTurnNum()
    {
        return turnNum;
    }

    public void beginGame()
    {
        int i = 0;
        while (i != 40)
        {
            System.out.println("Creating game...");
            ++i;
        }
        System.out.println("Game has begun, your word is...");
        for ( i = 0; i < hiddenWordLength; ++i)
        {
            System.out.print("*");
        }
        System.out.println("\nBegin your guesses.");
        alertDupes();
        guesses();
    }

    public void alertDupes()
    {
        //this method checks the hiddenWord to see if there are any duplicate letters, to ease some confusion
        int dupes = 0;

        for (int i = 0; i < hiddenWordLength; i++)
        {
            for (int j = i + 1; j < hiddenWordLength; j++)
            {
                if (hiddenWord.charAt(i) == hiddenWord.charAt(j))
                {
                    ++dupes;
                }
            }
        }
        System.out.println("There were " + dupes + " types of duplicate letters in the hidden word.");
    }
    public void guesses()
    {
        System.out.println("You have 6 chances to guess letters.");
        while(turnNum <= 6)
        {
        System.out.println("Turn " + turnNum);
        System.out.println("Enter your guess");
        char guess = scnr.next().charAt(0);




        //creative way to flag that the input is wrong
        int wrongLetterChecker = 0;

        for (int i = 0; i < hiddenWordLength; ++i)
        {
            if (guess == hiddenWord.charAt(i))
            {
                System.out.println("Correct!");
                correctGuesses.add(guess);
                wrongLetterChecker = -999;
                continue;
            }
            else
            {
                wrongLetterChecker++;
            }
        }
        if (wrongLetterChecker > 0)
        {
            incorrectGuesses.add(guess);
        }
        System.out.println("Your correct guesses are...");
        System.out.println(correctGuesses);
        System.out.println("Your incorrect guesses are...");
        System.out.println(incorrectGuesses);


        for(int i = 0; i < hiddenWordLength; ++i)
        {

        }
        ++turnNum;
        System.out.println();
        }
        finalGuess();
    }

    public void finalGuess()
    {
        turnNum = 0;
        correctGuesses.clear();
        incorrectGuesses.clear();
        System.out.println("Enter your final guess of the word.");
        String finalGuess = scnr.next();
        if (finalGuess.equals(hiddenWord))
        {
            System.out.println("You won!!!!");
        }
        else
        {
            System.out.println("You lost bruh.");
        }

    }
}
